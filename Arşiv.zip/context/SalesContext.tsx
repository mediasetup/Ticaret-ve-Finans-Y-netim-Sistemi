
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Document, Customer, Product, Payment, Account, Category, DocType, Status, Reconciliation, Transaction, EInvoiceIntegratorConfig, User, CompanyInfo } from '../types';
import { MOCK_DOCUMENTS, MOCK_CUSTOMERS, MOCK_PRODUCTS, MOCK_ACCOUNTS, MOCK_CATEGORIES, MOCK_USERS, DEFAULT_COMPANY_INFO } from '../constants';
import { fetchTCMBRates, ExchangeRates } from '../services/tcmb';

interface SalesContextType {
  documents: Document[];
  customers: Customer[];
  products: Product[];
  payments: Payment[];
  accounts: Account[];
  transactions: Transaction[]; 
  categories: Category[];
  reconciliations: Reconciliation[];
  einvoiceConfig: EInvoiceIntegratorConfig | null;
  users: User[]; 
  companyInfo: CompanyInfo | null; 
  currentRates: ExchangeRates | null;
  ratesLoading: boolean;
  ratesError: string | null;
  addDocument: (doc: Document) => void;
  updateDocument: (doc: Document) => void;
  deleteDocument: (id: string) => void;
  addCustomer: (customer: Customer) => void;
  addProduct: (product: Product) => void;
  updateProduct: (product: Product) => void;
  deleteProduct: (id: string) => boolean; 
  deleteCustomer: (id: string) => boolean;
  addPayment: (payment: Payment) => void;
  updatePayment: (payment: Payment) => void;
  deletePayment: (id: string) => void;
  updateCustomer: (id: string, customerData: Partial<Customer>) => void;
  getDocument: (id: string) => Document | undefined;
  addCategory: (category: Category) => void;
  updateCategory: (category: Category) => void;
  deleteCategory: (id: string) => void;
  addReconciliation: (rec: Reconciliation) => void;
  updateReconciliation: (rec: Reconciliation) => void;
  deleteReconciliation: (id: string) => void;
  addAccount: (account: Account) => void;
  updateAccount: (account: Account) => void;
  deleteAccount: (id: string) => boolean;
  addTransaction: (tx: Transaction) => void;
  transferFunds: (fromAccId: string, toAccId: string, amount: number, description: string) => void;
  updateEInvoiceConfig: (config: EInvoiceIntegratorConfig) => void;
  addUser: (user: User) => void; 
  updateUser: (user: User) => void; 
  deleteUser: (id: string) => void; 
  updateCompanyInfo: (info: CompanyInfo) => void; 
  refreshRates: () => void;
}

const SalesContext = createContext<SalesContextType | undefined>(undefined);

const CURRENT_APP_VERSION = 'v16.0.0'; 
const VERSION_STORAGE_KEY = 'kobi_sys_app_version';

const STORAGE_KEYS = {
    DOCUMENTS: 'kobi_documents_v16',
    CUSTOMERS: 'kobi_customers_v16',
    PRODUCTS: 'kobi_products_v16',
    PAYMENTS: 'kobi_payments_v16',
    ACCOUNTS: 'kobi_accounts_v16',
    TRANSACTIONS: 'kobi_transactions_v16',
    CATEGORIES: 'kobi_categories_v16',
    RECONCILIATIONS: 'kobi_reconciliations_v16',
    EINVOICE: 'kobi_einvoice_v16',
    USERS: 'kobi_users_v16',
    COMPANY_INFO: 'kobi_company_info_v16'
};

export const SalesProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  
  useEffect(() => {
      const storedVersion = localStorage.getItem(VERSION_STORAGE_KEY);
      
      if (storedVersion !== CURRENT_APP_VERSION) {
          console.warn(`Version mismatch detected! Client: ${storedVersion}, Server: ${CURRENT_APP_VERSION}. Performing hard reset...`);
          localStorage.clear();
          localStorage.setItem(VERSION_STORAGE_KEY, CURRENT_APP_VERSION);
          window.location.reload();
      }
  }, []);

  const [documents, setDocuments] = useState<Document[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.DOCUMENTS);
    return saved ? JSON.parse(saved) : MOCK_DOCUMENTS;
  });
  
  const [customers, setCustomers] = useState<Customer[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CUSTOMERS);
    return saved ? JSON.parse(saved) : MOCK_CUSTOMERS;
  });
  
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
    return saved ? JSON.parse(saved) : MOCK_PRODUCTS;
  });

  const [payments, setPayments] = useState<Payment[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PAYMENTS);
    return saved ? JSON.parse(saved) : [];
  });

  const [accounts, setAccounts] = useState<Account[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ACCOUNTS);
    return saved ? JSON.parse(saved) : MOCK_ACCOUNTS;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
      const saved = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
      return saved ? JSON.parse(saved) : [];
  });

  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
    return saved ? JSON.parse(saved) : MOCK_CATEGORIES;
  });

  const [reconciliations, setReconciliations] = useState<Reconciliation[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.RECONCILIATIONS);
    return saved ? JSON.parse(saved) : [];
  });

  const [einvoiceConfig, setEinvoiceConfig] = useState<EInvoiceIntegratorConfig | null>(() => {
      const saved = localStorage.getItem(STORAGE_KEYS.EINVOICE);
      return saved ? JSON.parse(saved) : null;
  });

  const [users, setUsers] = useState<User[]>(() => {
      const saved = localStorage.getItem(STORAGE_KEYS.USERS);
      return saved ? JSON.parse(saved) : MOCK_USERS;
  });

  const [companyInfo, setCompanyInfo] = useState<CompanyInfo | null>(() => {
      const saved = localStorage.getItem(STORAGE_KEYS.COMPANY_INFO);
      return saved ? JSON.parse(saved) : DEFAULT_COMPANY_INFO;
  });

  const [currentRates, setCurrentRates] = useState<ExchangeRates | null>(null);
  const [ratesLoading, setRatesLoading] = useState(false);
  const [ratesError, setRatesError] = useState<string | null>(null);

  const refreshRates = async () => {
      setRatesLoading(true);
      setRatesError(null);
      try {
          const rates = await fetchTCMBRates();
          setCurrentRates(rates);
      } catch (err) {
          setRatesError("TCMB kurları alınamadı.");
          setCurrentRates({ USD: 32.50, EUR: 35.20, date: 'Çevrimdışı Mod' });
      } finally {
          setRatesLoading(false);
      }
  };

  useEffect(() => {
      if (!einvoiceConfig || einvoiceConfig.isProduction) return; 

      const interval = setInterval(() => {
          setDocuments(prevDocs => {
              let hasChanges = false;
              const newDocs = prevDocs.map(doc => {
                  if (doc.eInvoiceStatus === 'QUEUED') {
                      hasChanges = true;
                      const isSuccess = Math.random() > 0.2;
                      const newStatus: 'SENT' | 'ERROR' = isSuccess ? 'SENT' : 'ERROR';
                      return {
                          ...doc,
                          eInvoiceStatus: newStatus,
                      };
                  }
                  return doc;
              });
              return hasChanges ? newDocs : prevDocs;
          });
      }, 15000); 

      return () => clearInterval(interval);
  }, [einvoiceConfig]);

  useEffect(() => {
      refreshRates();
  }, []);

  useEffect(() => { localStorage.setItem(STORAGE_KEYS.DOCUMENTS, JSON.stringify(documents)); }, [documents]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers)); }, [customers]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products)); }, [products]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(payments)); }, [payments]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(accounts)); }, [accounts]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions)); }, [transactions]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories)); }, [categories]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.RECONCILIATIONS, JSON.stringify(reconciliations)); }, [reconciliations]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.EINVOICE, JSON.stringify(einvoiceConfig)); }, [einvoiceConfig]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users)); }, [users]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.COMPANY_INFO, JSON.stringify(companyInfo)); }, [companyInfo]);

  const addDocument = (doc: Document) => setDocuments(prev => [doc, ...prev]);
  const updateDocument = (doc: Document) => setDocuments(prev => prev.map(d => d.id === doc.id ? doc : d));
  const deleteDocument = (id: string) => setDocuments(prev => prev.filter(d => d.id !== id));

  const addCustomer = (c: Customer) => setCustomers(prev => [...prev, c]);
  
  const deleteCustomer = (id: string): boolean => {
      const hasDocs = documents.some(d => d.customer.id === id);
      if (hasDocs) return false;
      setCustomers(prev => prev.filter(c => c.id !== id));
      return true;
  };

  const addProduct = (p: Product) => setProducts(prev => [...prev, p]);
  const updateProduct = (p: Product) => setProducts(prev => prev.map(prod => prod.id === p.id ? p : prod));
  
  const deleteProduct = (id: string): boolean => {
      const hasDocs = documents.some(d => d.items.some(i => i.productId === id));
      if (hasDocs) return false;
      setProducts(prev => prev.filter(p => p.id !== id));
      return true;
  };

  const updateCustomer = (id: string, data: Partial<Customer>) => {
      setCustomers(prev => prev.map(c => c.id === id ? { ...c, ...data } : c));
      setDocuments(prev => prev.map(doc => doc.customer.id === id ? { ...doc, customer: { ...doc.customer, ...data } } : doc));
  };

  const addTransaction = (tx: Transaction) => {
      setTransactions(prev => [tx, ...prev]);
      setAccounts(prev => prev.map(acc => {
          if (acc.id === tx.accountId) {
              return { ...acc, balance: acc.balance + tx.amount };
          }
          return acc;
      }));
  };

  const addPayment = (payment: Payment) => {
    const newPayments = [payment, ...payments];
    setPayments(newPayments);

    const acc = accounts.find(a => a.id === payment.accountId);
    if (acc) {
        addTransaction({
            id: `TX-${Date.now()}`,
            accountId: payment.accountId,
            date: payment.date,
            amount: payment.amount, 
            type: 'COLLECTION',
            description: `Tahsilat: ${payment.description || 'Fatura Ödemesi'}`,
            relatedId: payment.id,
            balanceAfter: acc.balance + payment.amount
        });
    }
  };

  const updatePayment = (updatedPayment: Payment) => {
      const newPayments = payments.map(p => p.id === updatedPayment.id ? updatedPayment : p);
      setPayments(newPayments);
  };

  const deletePayment = (id: string) => {
      const paymentToDelete = payments.find(p => p.id === id);
      if (!paymentToDelete) return;

      setAccounts(prev => prev.map(acc => {
          if (acc.id === paymentToDelete.accountId) {
              return { ...acc, balance: acc.balance - paymentToDelete.amount };
          }
          return acc;
      }));

      const newPayments = payments.filter(p => p.id !== id);
      setPayments(newPayments);
      setTransactions(prev => prev.filter(tx => tx.relatedId !== id));
  };

  const transferFunds = (fromAccId: string, toAccId: string, amount: number, description: string) => {
      const fromAcc = accounts.find(a => a.id === fromAccId);
      const toAcc = accounts.find(a => a.id === toAccId);
      
      if (!fromAcc || !toAcc) return;

      addTransaction({
          id: `TX-OUT-${Date.now()}`,
          accountId: fromAccId,
          date: new Date().toISOString().split('T')[0],
          amount: -amount,
          type: 'TRANSFER',
          description: `Transfer Çıkışı: ${toAcc.name} -> ${description}`,
          balanceAfter: fromAcc.balance - amount
      });

      addTransaction({
          id: `TX-IN-${Date.now()}`,
          accountId: toAccId,
          date: new Date().toISOString().split('T')[0],
          amount: amount, 
          type: 'TRANSFER',
          description: `Transfer Girişi: ${fromAcc.name} -> ${description}`,
          balanceAfter: toAcc.balance + amount
      });
  };

  const addCategory = (c: Category) => setCategories(prev => [...prev, c]);
  const updateCategory = (c: Category) => setCategories(prev => prev.map(cat => cat.id === c.id ? c : cat));
  const deleteCategory = (id: string) => setCategories(prev => prev.filter(c => c.id !== id));
  
  const addReconciliation = (r: Reconciliation) => setReconciliations(prev => [r, ...prev]);
  const updateReconciliation = (r: Reconciliation) => setReconciliations(prev => prev.map(rec => rec.id === r.id ? r : rec));
  const deleteReconciliation = (id: string) => setReconciliations(prev => prev.filter(r => r.id !== id));

  const addAccount = (acc: Account) => setAccounts(prev => [...prev, acc]);
  const updateAccount = (acc: Account) => setAccounts(prev => prev.map(a => a.id === acc.id ? acc : a));
  
  const deleteAccount = (id: string): boolean => {
      const hasTransactions = transactions.some(t => t.accountId === id);
      const hasPayments = payments.some(p => p.accountId === id);
      if (hasTransactions || hasPayments) return false;
      setAccounts(prev => prev.filter(a => a.id !== id));
      return true;
  };

  const updateEInvoiceConfig = (config: EInvoiceIntegratorConfig) => {
      setEinvoiceConfig(config);
  };

  const addUser = (user: User) => setUsers(prev => [...prev, user]);
  const updateUser = (user: User) => setUsers(prev => prev.map(u => u.id === user.id ? user : u));
  const deleteUser = (id: string) => setUsers(prev => prev.filter(u => u.id !== id));

  const updateCompanyInfo = (info: CompanyInfo) => {
      setCompanyInfo(info);
  };

  const getDocument = (id: string) => documents.find((doc) => doc.id === id);

  return (
    <SalesContext.Provider
      value={{
        documents, customers, products, payments, accounts, transactions, categories, reconciliations, einvoiceConfig, users, companyInfo,
        currentRates, ratesLoading, ratesError, refreshRates,
        addDocument, updateDocument, deleteDocument,
        addCustomer, addProduct, updateProduct, deleteProduct, deleteCustomer, updateCustomer,
        addPayment, updatePayment, deletePayment,
        addCategory, updateCategory, deleteCategory,
        addReconciliation, updateReconciliation, deleteReconciliation,
        addAccount, updateAccount, deleteAccount,
        addTransaction, transferFunds,
        updateEInvoiceConfig,
        addUser, updateUser, deleteUser,
        updateCompanyInfo,
        getDocument
      }}
    >
      {children}
    </SalesContext.Provider>
  );
};

export const useSales = () => {
  const context = useContext(SalesContext);
  if (!context) {
    throw new Error('useSales must be used within a SalesProvider');
  }
  return context;
};
