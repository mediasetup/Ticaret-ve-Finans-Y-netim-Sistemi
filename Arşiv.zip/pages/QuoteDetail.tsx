
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Printer, Pencil, FileCheck, Share2, Copy, Trash2, Download, Hexagon } from 'lucide-react';
import { useSales } from '../context/SalesContext';
import { DocType, Status, Document } from '../types';

declare var html2pdf: any;

const QuoteDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { getDocument, addDocument, updateDocument, deleteDocument, companyInfo } = useSales();
  const [doc, setDoc] = useState<Document | undefined>(undefined);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  useEffect(() => {
    if (id) {
      const found = getDocument(id);
      setDoc(found);
    }
  }, [id, getDocument]);

  if (!doc) return <div className="p-8 text-center">Teklif bulunamadı...</div>;

  const handleConvertToOrder = () => {
    const newOrder: Document = {
      ...doc,
      id: `SIP-${Math.floor(Math.random() * 10000)}`,
      type: DocType.ORDER,
      status: Status.PENDING,
      relatedDocId: doc.id,
      date: new Date().toISOString().split('T')[0],
    };
    
    const updatedQuote = { ...doc, status: Status.APPROVED };
    updateDocument(updatedQuote);
    addDocument(newOrder);
    
    alert('Sipariş başarıyla oluşturuldu.');
    navigate(`/sales/order/${newOrder.id}`);
  };

  const handleStatusChange = (newStatus: string) => {
      const updated = { ...doc, status: newStatus as Status };
      updateDocument(updated);
      setDoc(updated);
  };

  const getPdfOptions = (filename: string) => ({
      margin: [10, 10, 15, 10], 
      filename: filename,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true, letterRendering: true },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
      pagebreak: { mode: ['css', 'legacy'] }
  });

  const handleShare = async () => {
      if (navigator.share) {
          setIsGeneratingPdf(true);
          try {
              const element = document.getElementById('printable-area');
              const opt = getPdfOptions(`${doc.id}_Teklif.pdf`);

              const worker = html2pdf().set(opt).from(element);
              const pdfBlob = await worker.output('blob');
              
              const file = new File([pdfBlob], `${doc.id}_Teklif.pdf`, { type: 'application/pdf' });

              if (navigator.canShare && navigator.canShare({ files: [file] })) {
                  await navigator.share({
                      files: [file],
                      title: `${doc.id} Teklif`,
                      text: `Merhaba, ${doc.customer.name} firması için hazırlanan ${doc.id} nolu teklif ektedir.`
                  });
              } else {
                   throw new Error("Dosya paylaşımı desteklenmiyor.");
              }
          } catch (error) {
              console.error('Share failed:', error);
              const text = `Merhaba, ${doc.id} numaralı teklifiniz hazırdır. Toplam Tutar: ${doc.totalAmount.toLocaleString()} ${doc.currency}.`;
              window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
          } finally {
              setIsGeneratingPdf(false);
          }
      } else {
          const text = `Merhaba, ${doc.id} numaralı teklifiniz hazırdır. Toplam Tutar: ${doc.totalAmount} ${doc.currency}.`;
          window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
      }
  };

  const handleDelete = () => {
      if (window.confirm('Bu teklifi kalıcı olarak silmek istediğinize emin misiniz?')) {
          deleteDocument(doc.id);
          navigate('/sales/quotes');
      }
  };

  const handleDuplicate = () => {
      const newDoc: Document = {
          ...doc,
          id: `TEK-${Math.floor(Math.random() * 10000)}`,
          title: doc.title ? `${doc.title} (Kopya)` : 'Teklif Kopyası',
          status: Status.PENDING,
          date: new Date().toISOString().split('T')[0],
          items: doc.items.map(i => ({...i}))
      };
      addDocument(newDoc);
      alert('Teklif kopyalandı, düzenleme sayfasına yönlendiriliyorsunuz.');
      navigate(`/sales/quote/${newDoc.id}`);
  };

  const handleDownloadPDF = () => {
      setIsGeneratingPdf(true);
      const element = document.getElementById('printable-area');
      const opt = getPdfOptions(`${doc.id}_Teklif.pdf`);

      if (typeof html2pdf !== 'undefined') {
          html2pdf().set(opt).from(element).save().then(() => {
              setIsGeneratingPdf(false);
          });
      } else {
          alert('PDF kütüphanesi yüklenemedi. Lütfen sayfayı yenileyip tekrar deneyin.');
          setIsGeneratingPdf(false);
      }
  };

  const subTotal = doc.items.reduce((sum, i) => sum + (i.total || 0), 0);
  const totalTax = doc.items.reduce((sum, i) => sum + ((i.total || 0) * ((i.taxRate || 20) / 100)), 0);
  const grandTotal = subTotal + totalTax;

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-10 print:pb-0 print:max-w-none">
      <div className="flex flex-col md:flex-row justify-between gap-4 no-print">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-slate-200 rounded-full transition-colors">
            <ArrowLeft className="text-slate-600" />
          </button>
          <div>
             <h2 className="text-2xl font-bold text-slate-800">Teklif Detayı</h2>
             <span className="text-sm text-slate-500">{doc.title || doc.id}</span>
          </div>
        </div>
        <div className="flex gap-2 flex-wrap items-center">
           <button 
             onClick={handleDelete}
             className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
             title="Sil"
           >
             <Trash2 size={20} />
           </button>
           <button 
             onClick={handleDuplicate}
             className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
             title="Kopyala"
           >
             <Copy size={20} />
           </button>
           
           <div className="w-px h-6 bg-slate-300 mx-2"></div>

           <button 
             onClick={handleShare}
             disabled={isGeneratingPdf}
             className="flex items-center gap-2 px-3 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 shadow-sm text-sm"
           >
             <Share2 size={16} /> {isGeneratingPdf ? 'Oluşturuluyor...' : 'Paylaş (PDF)'}
           </button>
           
           <button 
             onClick={handleDownloadPDF} 
             disabled={isGeneratingPdf}
             className="flex items-center gap-2 px-3 py-2 bg-slate-700 text-white rounded-lg hover:bg-slate-800 text-sm shadow-sm"
             title="PDF Olarak İndir"
           >
             <Download size={16} /> PDF İndir
           </button>
           
           <button 
             onClick={() => navigate(`/sales/quote/${doc.id}`)} 
             className="flex items-center gap-2 px-3 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 text-sm font-medium"
           >
             <Pencil size={16} /> Düzenle
           </button>
           
           {doc.status !== Status.APPROVED && (
              <button 
                onClick={handleConvertToOrder} 
                className="flex items-center gap-2 px-3 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 shadow-sm text-sm font-medium"
              >
                <FileCheck size={16} /> Sipariş Oluştur
              </button>
           )}
        </div>
      </div>

      <div id="printable-area" className="bg-white rounded-xl shadow-sm border border-slate-200 p-8 print:shadow-none print:border-none print:p-0 print:rounded-none doc-container">
         
         <div className="flex justify-between items-start border-b border-slate-200 pb-6 mb-6">
             <div className="flex items-start gap-4">
                 <div className="h-16 w-24 flex items-center justify-center">
                    {companyInfo?.logoUrl ? <img src={companyInfo.logoUrl} alt="logo" className="max-w-full max-h-full object-contain" /> : <Hexagon size={36} strokeWidth={2.5} className="text-slate-300"/>}
                 </div>
                 <div>
                     <h1 className="text-xl font-bold text-slate-900 uppercase tracking-tight leading-none">{companyInfo?.name}</h1>
                     <div className="text-xs text-slate-500 space-y-0.5 leading-snug mt-2">
                         <p>{companyInfo?.address}</p>
                         <p>Tel: {companyInfo?.phone} | E-posta: {companyInfo?.email}</p>
                         <p>Mersis: {companyInfo?.mersisNo} | V.D.: {companyInfo?.taxOffice} | VKN: {companyInfo?.taxNo}</p>
                     </div>
                 </div>
             </div>
             <div className="text-right">
                 <h2 className="text-4xl font-bold text-slate-200 uppercase tracking-widest print:text-slate-300">TEKLİF</h2>
                 <p className="text-xl font-bold text-slate-800 mt-1">#{doc.id}</p>
                 <p className="text-base text-slate-500">{doc.date}</p>
             </div>
         </div>

         <div className="grid grid-cols-2 gap-12 mb-8">
            <div>
               <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-3">Sayın</h3>
               <div className="text-base text-slate-800">
                   <p className="font-bold text-lg mb-1">{doc.customer.name}</p>
                   <p className="whitespace-pre-line text-slate-600 mb-2">{doc.customer.address}</p>
                   {doc.customer.city && <p className="text-slate-600">{doc.customer.district} / {doc.customer.city}</p>}
                   
                   {(doc.customer.taxNo || doc.customer.phone) && (
                       <div className="mt-3 pt-3 border-t border-slate-100 text-slate-500 text-sm space-y-1">
                           {doc.customer.taxOffice && <p>V.D.: {doc.customer.taxOffice}</p>}
                           {doc.customer.taxNo && <p>VKN/TCKN: {doc.customer.taxNo}</p>}
                           {doc.customer.phone && <p>Tel: {doc.customer.phone}</p>}
                       </div>
                   )}
               </div>
            </div>
            
            <div className="text-right">
               <div className="bg-slate-50 rounded-lg p-5 print:bg-transparent print:border print:border-slate-100">
                   <div className="flex justify-between items-center mb-3 no-print">
                      <span className="text-sm font-bold text-slate-500 uppercase">Durum</span>
                      <select 
                        value={doc.status} 
                        onChange={(e) => handleStatusChange(e.target.value)}
                        className={`text-sm font-bold border-none rounded px-2 py-1 cursor-pointer focus:ring-0 text-right ${doc.status === Status.APPROVED ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-700'}`}
                      >
                          <option value={Status.DRAFT}>{Status.DRAFT}</option>
                          <option value={Status.PENDING}>{Status.PENDING}</option>
                          <option value={Status.APPROVED}>{Status.APPROVED}</option>
                          <option value={Status.REJECTED}>{Status.REJECTED}</option>
                          <option value={Status.CANCELLED}>{Status.CANCELLED}</option>
                      </select>
                   </div>

                   <div className="hidden print:flex justify-between items-center mb-3">
                      <span className="text-sm font-bold text-slate-500 uppercase">Durum</span>
                      <span className={`px-2 py-1 rounded text-sm font-bold ${doc.status === Status.APPROVED ? 'bg-green-100 text-green-700' : 'bg-slate-200 text-slate-700'}`}>{doc.status}</span>
                   </div>
                   
                   {doc.title && (
                       <div className="mb-4 text-left">
                           <span className="text-sm font-bold text-slate-500 uppercase block mb-1">Konu</span>
                           <p className="font-medium text-slate-800">{doc.title}</p>
                       </div>
                   )}

                   <div className="text-left">
                        <span className="text-sm font-bold text-slate-500 uppercase block mb-1">Geçerlilik Tarihi</span>
                        <p className="font-medium text-slate-800">{doc.paymentDueDate || '-'}</p>
                   </div>
               </div>
            </div>
         </div>

         <div className="mb-8">
             <table className="w-full text-left text-sm border-collapse">
                <thead>
                   <tr className="bg-slate-100 text-slate-600 uppercase tracking-wider border-b border-slate-200">
                     <th className="py-3 px-4 font-bold text-left w-[45%] rounded-tl-lg">Hizmet / Ürün</th>
                     <th className="py-3 px-4 font-bold text-center">Miktar</th>
                     <th className="py-3 px-4 font-bold text-center">Birim</th>
                     <th className="py-3 px-4 font-bold text-right">Br. Fiyat</th>
                     <th className="py-3 px-4 font-bold text-center">KDV</th>
                     <th className="py-3 px-4 font-bold text-right rounded-tr-lg">Tutar</th>
                   </tr>
                </thead>
                <tbody className="text-slate-700">
                   {doc.items.map((item, idx) => (
                      <tr key={idx} className="border-b border-slate-100 last:border-none avoid-break">
                         <td className="py-3 px-4 align-top">
                            {item.sku && <div className="font-bold text-slate-900 text-sm mb-0.5">{item.sku}</div>}
                            <div className={`${item.sku ? 'text-slate-800' : 'font-bold text-slate-900'} text-sm`}>{item.productName}</div>
                            {item.description && <div className="text-xs text-slate-500 mt-1">{item.description}</div>}
                            {item.deliveryNote && (
                                <div className="text-xs text-slate-500 italic mt-1.5 bg-slate-50 inline-block px-1.5 py-0.5 rounded border border-slate-100">
                                    Teslimat: {item.deliveryNote}
                                </div>
                            )}
                         </td>
                         <td className="py-3 px-4 text-center align-top font-medium">{item.quantity}</td>
                         <td className="py-3 px-4 text-center align-top text-xs text-slate-500">{item.unit || 'Adet'}</td>
                         <td className="py-3 px-4 text-right align-top whitespace-nowrap">
                            {item.unitPrice.toLocaleString('tr-TR', { minimumFractionDigits: 2 })} {doc.currency}
                         </td>
                         <td className="py-3 px-4 text-center align-top text-xs">
                             %{item.taxRate || 20}
                         </td>
                         <td className="py-3 px-4 text-right align-top font-bold text-slate-800 whitespace-nowrap">
                            {item.total.toLocaleString('tr-TR', { minimumFractionDigits: 2 })} {doc.currency}
                         </td>
                      </tr>
                   ))}
                </tbody>
             </table>
         </div>

         <div className="flex flex-row justify-end border-t border-slate-200 pt-6 avoid-break">
             <div className="w-72">
                 <div className="flex justify-between text-sm text-slate-600 mb-2">
                    <span>Ara Toplam</span>
                    <span className="font-medium">{subTotal.toLocaleString('tr-TR', { minimumFractionDigits: 2 })} {doc.currency}</span>
                 </div>
                 <div className="flex justify-between text-sm text-slate-600 mb-3 pb-3 border-b border-slate-100">
                      <span>Toplam KDV</span>
                      <span className="font-medium">{totalTax.toLocaleString('tr-TR', { minimumFractionDigits: 2 })} {doc.currency}</span>
                 </div>
                 <div className="flex justify-between text-xl font-bold text-slate-900">
                    <span>GENEL TOPLAM</span>
                    <span>{grandTotal.toLocaleString('tr-TR', { minimumFractionDigits: 2 })} {doc.currency}</span>
                 </div>
                 {doc.currency !== 'TRY' && doc.exchangeRate && (
                   <div className="text-right text-xs text-slate-400 mt-1">
                      (Kur: {doc.exchangeRate.toFixed(4)})
                   </div>
                 )}
             </div>
         </div>
         
         {(doc.notes || doc.terms) && (
           <div className="mt-8 pt-6 border-t border-slate-200 grid grid-cols-1 gap-6 avoid-break">
             {doc.terms && (
                 <div>
                    <h4 className="font-bold text-xs text-slate-400 uppercase mb-2">Teklif Koşulları</h4>
                    <p className="text-slate-600 text-xs whitespace-pre-wrap leading-relaxed">{doc.terms}</p>
                 </div>
             )}
             {doc.notes && (
                 <div>
                    <h4 className="font-bold text-xs text-slate-400 uppercase mb-2">Notlar</h4>
                    <p className="text-slate-600 text-xs whitespace-pre-wrap leading-relaxed">{doc.notes}</p>
                 </div>
             )}
           </div>
         )}
         
         <div className="mt-16 pt-8 flex justify-between text-xs text-slate-400 avoid-break">
             <div>
                 <p className="font-bold text-slate-600 mb-8">Teslim Eden</p>
                 <p className="border-t border-slate-300 w-40 pt-1">İmza</p>
             </div>
             <div>
                 <p className="font-bold text-slate-600 mb-8">Teslim Alan</p>
                 <p className="border-t border-slate-300 w-40 pt-1">İmza</p>
             </div>
         </div>
         
         <div className="mt-8 text-center text-[10px] text-slate-300 avoid-break">
             Bu belge KOBİ Sys tarafından {new Date().toLocaleDateString('tr-TR')} tarihinde oluşturulmuştur.
         </div>
      </div>

      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #printable-area, #printable-area * {
            visibility: visible;
          }
          #printable-area {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            margin: 0;
            padding: 0;
            border: none;
            box-shadow: none;
          }
          html, body {
            height: auto;
            overflow: visible;
            background: white !important;
          }
          .no-print { display: none !important; }
        }
        
        .avoid-break {
            page-break-inside: avoid;
            break-inside: avoid;
        }
        tr.avoid-break {
            page-break-inside: avoid;
            page-break-after: auto;
        }
      `}</style>
    </div>
  );
};

export default QuoteDetail;
