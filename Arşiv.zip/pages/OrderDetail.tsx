import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Share2, FileCode, Pencil, Trash2, X, Download, Plus, Save, Calendar, Clock, CreditCard, Truck, CheckCircle, AlertTriangle, Send } from 'lucide-react';
import { useSales } from '../context/SalesContext';
import { DocType, Status, ItemStatus, LineItem, Document, Payment, Currency } from '../types';

declare var html2pdf: any;

const OrderDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { getDocument, updateDocument, addDocument, documents, deleteDocument, addPayment, updatePayment, deletePayment, payments, accounts, einvoiceConfig, companyInfo } = useSales();
  const [doc, setDoc] = useState<Document | undefined>(undefined);
  
  const [isInvoiceModalOpen, setIsInvoiceModalOpen] = useState(false);
  const [invoiceQuantities, setInvoiceQuantities] = useState<{[key: string]: number}>({});

  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [editingPaymentId, setEditingPaymentId] = useState<string | null>(null);
  const [payAmount, setPayAmount] = useState('');
  const [payCurrency, setPayCurrency] = useState<Currency>('TRY');
  const [payExchangeRate, setPayExchangeRate] = useState<number>(1.0);
  const [payDesc, setPayDesc] = useState('Fatura Tahsilatı');
  const [selectedAccountId, setSelectedAccountId] = useState('');
  
  const [useCurrentRate, setUseCurrentRate] = useState(true); 
  const [processingRate, setProcessingRate] = useState(1.0); 

  const [editingTerminIndex, setEditingTerminIndex] = useState<number | null>(null);
  const [tempTerminDate, setTempTerminDate] = useState('');
  
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [isSendingEInvoice, setIsSendingEInvoice] = useState(false);

  useEffect(() => {
    if (id) {
      const found = getDocument(id);
      if (found) {
        setDoc(found);
        setPayCurrency(found.currency); 
      }
    }
  }, [id, getDocument, documents]); 

  const availableAccounts = accounts.filter(acc => acc.currency === payCurrency);

  useEffect(() => {
     if (availableAccounts.length > 0 && !selectedAccountId) {
         setSelectedAccountId(availableAccounts[0].id);
     }
  }, [payCurrency, accounts]);

  useEffect(() => {
    if (!editingPaymentId) {
        if (payCurrency === 'TRY') setPayExchangeRate(1.0);
        if (payCurrency === 'USD') setPayExchangeRate(32.50);
        if (payCurrency === 'EUR') setPayExchangeRate(35.20);
    }
 }, [payCurrency, editingPaymentId]);

  if (!doc) return <div className="p-8 text-center">Yükleniyor veya bulunamadı...</div>;

  const isInvoice = doc.type === DocType.INVOICE;
  const isFullyShipped = !isInvoice && doc.items.every(item => (item.shippedQuantity || 0) >= item.quantity);
  
  const subTotal = doc.items.reduce((sum, item) => sum + (item.total || 0), 0);
  const totalDiscount = doc.items.reduce((sum, i) => sum + ((i.unitPrice * i.quantity) * (i.discount / 100)), 0);
  const vatAmount = doc.items.reduce((sum, i) => sum + ((i.total || 0) * ((i.taxRate || 20) / 100)), 0);
  const grandTotal = subTotal + vatAmount;

  const invoicePayments = isInvoice ? payments.filter(p => p.docId === doc.id) : [];
  
  const totalPaidEffective = invoicePayments.reduce((sum, p) => {
      if (p.currency === doc.currency) return sum + p.amount;
      const rate = p.processingRate || 1.0;
      return sum + (p.amount / rate);
  }, 0);

  const remainingBalance = grandTotal - totalPaidEffective;

  const handleDelete = () => {
    if (window.confirm('Bu belgeyi silmek istediğinize emin misiniz?')) {
        deleteDocument(doc.id);
        navigate(isInvoice ? '/sales/invoices' : '/sales/orders');
    }
  };

  const handleEdit = () => navigate(`/sales/order/edit/${doc.id}`);

  const handleShare = () => {
    const text = `Merhaba, ${doc.id} numaralı ${doc.type === DocType.INVOICE ? 'Faturanız' : 'Siparişiniz'} hakkında bilgilendirme. Toplam: ${grandTotal.toLocaleString()} ${doc.currency}.`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handleSendEInvoice = () => {
      if (doc.eInvoiceStatus === 'SENT' || doc.eInvoiceStatus === 'QUEUED') {
          alert("Bu fatura zaten gönderilmiş veya kuyrukta.");
          return;
      }

      if (!doc.customer.taxNo) {
          alert("E-Fatura göndermek için müşterinin VKN/TCKN bilgisi zorunludur.");
          return;
      }

      setIsSendingEInvoice(true);

      setTimeout(() => {
          const updatedDoc = {
              ...doc,
              eInvoiceStatus: 'QUEUED' as const,
              eInvoiceNumber: `GIB${new Date().getFullYear()}${Math.floor(100000000 + Math.random() * 900000000)}`
          };
          updateDocument(updatedDoc);
          setDoc(updatedDoc);
          setIsSendingEInvoice(false);
          alert("Fatura başarıyla GİB gönderim kuyruğuna alındı. Entegratör yanıtı bekleniyor.");
      }, 2000);
  };

  const openInvoiceModal = () => {
      if (isFullyShipped) {
          alert("Bu siparişteki tüm ürünler zaten sevk edilmiş/faturalandırılmış.");
          return;
      }

      const initialQtys: {[key: string]: number} = {};
      let hasItems = false;
      
      doc.items.forEach((item, index) => {
          const remaining = item.quantity - (item.shippedQuantity || 0);
          if (remaining > 0) {
              initialQtys[index] = remaining;
              hasItems = true;
          } else {
              initialQtys[index] = 0;
          }
      });

      if (!hasItems) {
           alert("Faturalandırılacak açık miktar bulunamadı.");
           return;
      }

      setInvoiceQuantities(initialQtys);
      setIsInvoiceModalOpen(true);
  };

  const executeInvoiceConversion = () => {
      const itemsToInvoice: LineItem[] = [];
      const updatedOrderItems = [...doc.items];

      doc.items.forEach((item, index) => {
          const qtyToInvoice = invoiceQuantities[index] || 0;
          if (qtyToInvoice > 0) {
              itemsToInvoice.push({
                  ...item,
                  quantity: qtyToInvoice, 
                  shippedQuantity: 0, 
                  total: qtyToInvoice * item.unitPrice * (1 - (item.discount || 0)/100)
              });

              const currentShipped = (item.shippedQuantity || 0) + qtyToInvoice;
              updatedOrderItems[index] = {
                  ...item,
                  shippedQuantity: currentShipped,
                  itemStatus: currentShipped >= item.quantity ? ItemStatus.SHIPPED : ItemStatus.PREPARING
              };
          }
      });

      if (itemsToInvoice.length === 0) {
          alert("Lütfen en az bir ürün için miktar giriniz.");
          return;
      }

      const invoiceTotal = itemsToInvoice.reduce((sum, i) => sum + i.total, 0);
      const now = new Date();
      const newInvoice: Document = {
          ...doc,
          id: `FTR-${Math.floor(Math.random() * 10000)}`,
          type: DocType.INVOICE,
          status: Status.INVOICED,
          relatedDocId: doc.id,
          date: now.toISOString().split('T')[0],
          createdAt: now.toISOString(),
          items: itemsToInvoice,
          totalAmount: invoiceTotal,
          eInvoiceStatus: 'DRAFT'
      };

      addDocument(newInvoice);
      
      const totalOrdered = updatedOrderItems.reduce((a,b) => a + b.quantity, 0);
      const totalShipped = updatedOrderItems.reduce((a,b) => a + (b.shippedQuantity || 0), 0);
      
      let newOrderStatus = Status.SHIPPED;
      if (totalShipped > 0 && totalShipped < totalOrdered) newOrderStatus = Status.PARTIAL;
      else if (totalShipped === 0) newOrderStatus = Status.PENDING;
      else newOrderStatus = Status.SHIPPED; 

      const updatedOrder = { ...doc, items: updatedOrderItems, status: newOrderStatus };
      updateDocument(updatedOrder);
      setDoc(updatedOrder);
      setIsInvoiceModalOpen(false);
      alert(`Fatura başarıyla oluşturuldu! #${newInvoice.id}`);
      navigate(`/sales/invoice/${newInvoice.id}`);
  };

  const openPaymentModal = (payId?: string) => {
      if (payId) {
          const pay = payments.find(p => p.id === payId);
          if (pay) {
              setEditingPaymentId(payId);
              setPayAmount(pay.amount.toString());
              setPayCurrency(pay.currency);
              setPayExchangeRate(pay.exchangeRate);
              setPayDesc(pay.description || '');
              setSelectedAccountId(pay.accountId);
              setProcessingRate(pay.processingRate || 1.0);
              if (pay.processingRate && pay.processingRate !== doc.exchangeRate) {
                  setUseCurrentRate(true);
              } else {
                  setUseCurrentRate(false);
              }
              setIsPaymentModalOpen(true);
          }
      } else {
          setEditingPaymentId(null);
          if (payCurrency === doc.currency) {
              setPayAmount(remainingBalance > 0 ? remainingBalance.toFixed(2) : '');
          } else {
              setPayAmount(''); 
          }
          setPayDesc('Fatura Tahsilatı');
          setIsPaymentModalOpen(true);
      }
  };

  const handleSavePayment = () => {
    if (!payAmount || parseFloat(payAmount) <= 0) {
        alert("Geçerli bir tutar giriniz.");
        return;
    }
    if (!selectedAccountId) {
        alert("Kasa/Banka hesabı seçiniz.");
        return;
    }

    let finalProcRate = 1.0;
    if (doc.currency !== payCurrency) {
        if (useCurrentRate) {
            finalProcRate = processingRate;
        } else {
            finalProcRate = doc.exchangeRate || 1.0;
        }
    }

    const paymentData: Payment = {
        id: editingPaymentId || `PAY-${Date.now()}`,
        customerId: doc.customer.id,
        docId: doc.id,
        accountId: selectedAccountId,
        date: new Date().toISOString().split('T')[0],
        amount: parseFloat(payAmount),
        currency: payCurrency,
        exchangeRate: payExchangeRate, 
        processingRate: finalProcRate, 
        description: payDesc,
        type: 'COLLECTION',
        method: 'BANK'
    };

    if (editingPaymentId) {
        updatePayment(paymentData);
        alert("Tahsilat güncellendi.");
    } else {
        addPayment(paymentData);
        alert("Tahsilat eklendi.");
    }
    
    setIsPaymentModalOpen(false);
  };

  const handleDeletePayment = (payId: string) => {
      if (window.confirm("Bu tahsilat kaydını silmek istediğinize emin misiniz? Fatura bakiyesi güncellenecektir.")) {
          deletePayment(payId);
      }
  };

  const generateUBLXML = () => {
      const itemsXML = doc.items.map((item, index) => `
        <cac:InvoiceLine>
            <cbc:ID>${index + 1}</cbc:ID>
            <cbc:InvoicedQuantity unitCode="NIU">${item.quantity}</cbc:InvoicedQuantity>
            <cbc:LineExtensionAmount currencyID="${doc.currency}">${item.total.toFixed(2)}</cbc:LineExtensionAmount>
            <cac:Item>
                <cbc:Name>${item.productName}</cbc:Name>
            </cac:Item>
            <cac:Price>
                <cbc:PriceAmount currencyID="${doc.currency}">${item.unitPrice.toFixed(2)}</cbc:PriceAmount>
            </cac:Price>
        </cac:InvoiceLine>`).join('');

      const xmlString = `<?xml version="1.0" encoding="UTF-8"?>
<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
         xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
         xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2">
    <cbc:ID>${doc.id}</cbc:ID>
    <cbc:IssueDate>${doc.date}</cbc:IssueDate>
    <cac:AccountingSupplierParty>
        <cac:Party>
            <cac:PartyName><cbc:Name>${companyInfo?.name}</cbc:Name></cac:PartyName>
        </cac:Party>
    </cac:AccountingSupplierParty>
    <cac:AccountingCustomerParty>
        <cac:Party>
            <cac:PartyName><cbc:Name>${doc.customer.name}</cbc:Name></cac:PartyName>
        </cac:Party>
    </cac:AccountingCustomerParty>
    <cac:LegalMonetaryTotal>
        <cbc:LineExtensionAmount currencyID="${doc.currency}">${subTotal.toFixed(2)}</cbc:LineExtensionAmount>
        <cbc:TaxExclusiveAmount currencyID="${doc.currency}">${subTotal.toFixed(2)}</cbc:TaxExclusiveAmount>
        <cbc:TaxInclusiveAmount currencyID="${doc.currency}">${grandTotal.toFixed(2)}</cbc:TaxInclusiveAmount>
        <cbc:PayableAmount currencyID="${doc.currency}">${grandTotal.toFixed(2)}</cbc:PayableAmount>
    </cac:LegalMonetaryTotal>
    ${itemsXML}
</Invoice>`;

      const blob = new Blob([xmlString], { type: 'application/xml' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${doc.id}.xml`;
      a.click();
      URL.revokeObjectURL(url);
  };
  
  const goBack = () => navigate(-1);

  const saveTerminDate = (index: number) => {
      const updatedItems = [...doc.items];
      updatedItems[index] = { ...updatedItems[index], balanceDeadline: tempTerminDate };
      const updatedDoc = { ...doc, items: updatedItems };
      updateDocument(updatedDoc);
      setDoc(updatedDoc);
      setEditingTerminIndex(null);
  };

  const handleDownloadPDF = () => {
      setIsGeneratingPdf(true);
      const element = document.getElementById('printable-area');
      const filename = `${doc.type === DocType.INVOICE ? 'Fatura' : 'Siparis'}_${doc.id}.pdf`;
      const opt = {
          margin: [10, 10, 15, 10],
          filename: filename,
          image: { type: 'jpeg', quality: 0.98 },
          html2canvas: { scale: 2, useCORS: true, letterRendering: true },
          jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
          pagebreak: { mode: ['css', 'legacy'] }
      };

      if (typeof html2pdf !== 'undefined') {
          html2pdf().set(opt).from(element).save().then(() => setIsGeneratingPdf(false));
      } else {
          alert('PDF hatası.');
          setIsGeneratingPdf(false);
      }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12 print:pb-0 print:max-w-none">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 no-print">
        <div className="flex items-center gap-4">
          <button onClick={goBack} className="p-2 hover:bg-slate-200 rounded-full transition-colors">
            <ArrowLeft className="text-slate-600" />
          </button>
          <div>
            <h2 className="text-2xl font-bold text-slate-800">{isInvoice ? 'Fatura Detayı' : 'Sipariş Detayı'}</h2>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
           <button onClick={handleDelete} className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg"><Trash2 size={20} /></button>
           {!isInvoice && <button onClick={handleEdit} className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg"><Pencil size={20} /></button>}
           <div className="w-px h-6 bg-slate-300 mx-1"></div>
           <button onClick={handleShare} className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 shadow-sm"><Share2 size={18} /> Paylaş</button>
           
           {isInvoice && (
            <>
               <button onClick={generateUBLXML} className="flex items-center gap-2 px-4 py-2 bg-slate-700 text-white rounded-lg hover:bg-slate-800 font-medium"><FileCode size={18} /> e-Fatura XML</button>
               {(!doc.eInvoiceStatus || doc.eInvoiceStatus === 'DRAFT' || doc.eInvoiceStatus === 'ERROR') && (
                   <button onClick={handleSendEInvoice} disabled={isSendingEInvoice} className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-medium shadow-sm">{isSendingEInvoice ? <span className="animate-pulse">Gönderiliyor...</span> : <><Send size={18} /> GİB'e Gönder</>}</button>
               )}
               {doc.status !== Status.PAID && (
                   <button onClick={() => openPaymentModal()} className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 font-medium shadow-sm"><Plus size={18} /> Tahsilat Ekle</button>
               )}
            </>
           )}

          <button onClick={handleDownloadPDF} disabled={isGeneratingPdf} className="flex items-center gap-2 px-4 py-2 border border-slate-300 rounded-lg bg-white text-slate-700 hover:bg-slate-50 font-medium">{isGeneratingPdf ? <span className="animate-pulse">Oluşturuluyor...</span> : <><Download size={18} /> PDF İndir</>}
          </button>

          {isInvoice && doc.eInvoiceStatus === 'SENT' && (
              <button onClick={() => alert("GİB İmzalı PDF İndirildi (Simülasyon)")} className="flex items-center gap-2 px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-900 font-medium"><FileCode size={18} /> GİB PDF</button>
          )}

          {!isInvoice && (
              <button onClick={openInvoiceModal} disabled={isFullyShipped} className={`flex items-center gap-2 px-4 py-2 text-white rounded-lg font-medium shadow-sm ${isFullyShipped ? 'bg-slate-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'}`}>Faturaya Dönüştür</button>
          )}
        </div>
      </div>

      <div id="printable-area" className="bg-white rounded-xl shadow-sm border border-slate-200 p-8 print:shadow-none print:border-none print:p-0">
           <div className="flex justify-between items-start pb-6 mb-8">
               <div className="flex items-start gap-4">
                 <div className="h-16 w-24 flex items-center justify-center">
                     {companyInfo?.logoUrl ? <img src={companyInfo.logoUrl} alt="logo" className="max-w-full max-h-full object-contain" /> : <div className="w-16 h-16 bg-transparent"></div>}
                 </div>
                 <div>
                     <h1 className="text-xl font-bold text-slate-900 uppercase tracking-tight leading-none">{companyInfo?.name}</h1>
                     <div className="text-xs text-slate-500 space-y-0.5 mt-2 leading-snug">
                         <p>{companyInfo?.address}</p>
                         <p>Tel: {companyInfo?.phone} | E-posta: {companyInfo?.email}</p>
                         <p>Mersis: {companyInfo?.mersisNo} | V.D.: {companyInfo?.taxOffice} | VKN: {companyInfo?.taxNo}</p>
                     </div>
                 </div>
               </div>
               <div className="text-right shrink-0">
                   <h2 className="text-3xl font-bold text-slate-200 uppercase tracking-widest print:text-slate-300">{isInvoice ? 'FATURA' : 'SİPARİŞ'}</h2>
                   <p className="text-xl font-bold text-slate-800 mt-1">#{doc.id}</p>
                   <p className="text-slate-500">{doc.date}</p>
                   
                   {isInvoice && doc.eInvoiceStatus && (
                       <div className="mt-2 mb-1 flex flex-col items-end gap-1">
                           <span className={`px-3 py-1 rounded-full text-xs font-bold border flex items-center justify-end gap-1 w-fit ml-auto
                                ${doc.eInvoiceStatus === 'QUEUED' ? 'bg-orange-50 text-orange-700 border-orange-200' : 
                                  doc.eInvoiceStatus === 'SENT' ? 'bg-green-50 text-green-700 border-green-200' : 
                                  doc.eInvoiceStatus === 'ERROR' ? 'bg-red-50 text-red-700 border-red-200' : 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                               {doc.eInvoiceStatus === 'QUEUED' && <Clock size={12}/>}
                               {doc.eInvoiceStatus === 'SENT' && <CheckCircle size={12}/>}
                               {doc.eInvoiceStatus === 'ERROR' && <AlertTriangle size={12}/>}
                               {doc.eInvoiceStatus === 'QUEUED' ? 'GİB KUYRUKTA' : 
                                doc.eInvoiceStatus === 'SENT' ? 'GÖNDERİLDİ' : 
                                doc.eInvoiceStatus === 'ERROR' ? 'HATA / RED' : doc.eInvoiceStatus}
                           </span>
                           {doc.eInvoiceNumber && <p className="text-xs font-mono text-slate-400 mt-1">{doc.eInvoiceNumber}</p>}
                       </div>
                   )}

                   {isInvoice && (
                       <div className="mt-2">
                           <span className={`px-3 py-1 rounded-full text-xs font-bold ${doc.status === Status.PAID ? 'bg-green-100 text-green-700' : doc.status === Status.PARTIAL_PAID ? 'bg-orange-100 text-orange-700' : 'bg-red-100 text-red-700'}`}>
                               {doc.status === Status.PAID ? 'ÖDENDİ' : doc.status === Status.PARTIAL_PAID ? 'KISMI ÖDENDİ' : 'ÖDENMEDİ'}
                           </span>
                       </div>
                   )}
               </div>
          </div>
          
          <div className="grid grid-cols-2 gap-12 mb-8">
              <div>
                  <h3 className="text-xs font-bold text-slate-400 uppercase mb-2">Sayın</h3>
                  <div className="text-slate-800">
                      <p className="font-bold text-lg">{doc.customer.name}</p>
                      <p className="text-slate-600 whitespace-pre-line">{doc.customer.address}</p>
                      <p className="text-slate-600">{doc.customer.district && `${doc.customer.district}/`}{doc.customer.city}</p>
                      {(doc.customer.taxNo) && (
                          <div className="mt-2 text-xs text-slate-500">
                              {doc.customer.taxOffice && <span>{doc.customer.taxOffice} V.D. | </span>}
                              <span>VKN: {doc.customer.taxNo}</span>
                          </div>
                      )}
                  </div>
              </div>
              <div className="text-right">
                   <div className="bg-slate-50 rounded-lg p-4 print:bg-transparent print:p-0 w-fit ml-auto">
                       <div className="mb-2">
                           <span className="text-xs font-bold text-slate-400 uppercase block">Vade Tarihi</span>
                           <span className="font-medium">{doc.paymentDueDate || '-'}</span>
                       </div>
                       {!isInvoice && (
                           <div>
                               <span className="text-xs font-bold text-slate-400 uppercase block">Durum</span>
                               <span className="font-medium text-blue-600">{doc.status}</span>
                           </div>
                       )}
                   </div>
              </div>
          </div>

          <table className="w-full text-left text-sm mb-8 border-collapse">
              <thead className="bg-slate-100 text-slate-600 uppercase text-xs border-b border-t border-slate-200">
                  <tr>
                      <th className="py-3 px-4 font-bold rounded-tl-lg">No</th>
                      <th className="py-3 px-4 font-bold">Hizmet / Ürün Adı</th>
                      <th className="py-3 px-4 font-bold">Açıklama</th>
                      <th className="py-3 px-4 font-bold text-center">Miktar</th>
                      <th className="py-3 px-4 font-bold text-right">Birim Fiyat</th>
                      <th className="py-3 px-4 font-bold text-right">İndirim</th>
                      <th className="py-3 px-4 font-bold text-center">KDV</th>
                      <th className="py-3 px-4 font-bold text-right rounded-tr-lg">Toplam</th>
                  </tr>
              </thead>
              <tbody className="text-slate-700">
                  {doc.items.map((item, idx) => (
                      <tr key={idx} className="border-b border-slate-100 last:border-none page-break-inside-avoid">
                         <td className="py-3 px-4 text-slate-500">{idx + 1}</td>
                         <td className="py-3 px-4 font-bold text-slate-800">{item.productName}</td>
                         <td className="py-3 px-4 text-slate-500 text-xs">{item.sku}</td>
                         <td className="py-3 px-4 text-center align-top font-medium">{item.quantity} {item.unit}</td>
                         <td className="py-3 px-4 text-right align-top">{item.unitPrice.toLocaleString()} {doc.currency}</td>
                         <td className="py-3 px-4 text-right align-top text-xs text-slate-500">{item.discount > 0 ? `${item.discount}%` : '-'}</td>
                         <td className="py-3 px-4 text-center align-top text-xs">%{item.taxRate}</td>
                         <td className="py-3 px-4 text-right align-top font-bold text-slate-900">{item.total.toLocaleString()} {doc.currency}</td>
                      </tr>
                  ))}
              </tbody>
          </table>

          <div className="flex justify-end border-t border-slate-200 pt-6">
               <div className="w-96 space-y-2 text-right">
                  <div className="flex justify-between text-sm text-slate-600"><span>Mal Hizmet Toplam Tutarı</span><span>{subTotal.toLocaleString(undefined, {minimumFractionDigits: 2})} {doc.currency}</span></div>
                  <div className="flex justify-between text-sm text-slate-600"><span>Toplam İndirim</span><span>{totalDiscount.toLocaleString(undefined, {minimumFractionDigits: 2})} {doc.currency}</span></div>
                  <div className="flex justify-between text-sm text-slate-600"><span>Hesaplanan KDV (%20)</span><span>{vatAmount.toLocaleString(undefined, {minimumFractionDigits: 2})} {doc.currency}</span></div>
                  <div className="flex justify-between text-sm font-bold text-slate-800 pt-2 border-t border-slate-200"><span>Vergiler Dahil Toplam Tutar</span><span>{grandTotal.toLocaleString(undefined, {minimumFractionDigits: 2})} {doc.currency}</span></div>
                  <div className="flex justify-between text-xl font-bold text-slate-900 bg-slate-100 p-2 rounded-lg mt-2"><span>ÖDENECEK TUTAR</span><span>{grandTotal.toLocaleString(undefined, {minimumFractionDigits: 2})} {doc.currency}</span></div>
              </div>
          </div>
      </div>
      
      {isInvoice && invoicePayments.length > 0 && (
          <div className="mt-8 no-print">
              <h3 className="font-bold text-slate-800 mb-4 px-1">Ödeme Geçmişi</h3>
              <div className="bg-slate-50 rounded-xl border border-slate-200 p-4 space-y-3">
                  {invoicePayments.map(p => (
                      <div key={p.id} className="flex items-center justify-between bg-white p-3 rounded-lg border border-slate-200 shadow-sm group">
                          <div className="flex items-center gap-3">
                              <div className="bg-emerald-100 text-emerald-600 p-2 rounded-full"><CreditCard size={18} /></div>
                              <div>
                                  <p className="text-sm font-bold text-slate-800">Tahsilat</p>
                                  <div className="flex items-center gap-2 text-xs text-slate-500">
                                      <span>{p.date}</span>
                                      <span>• {p.description || 'Açıklama yok'}</span>
                                      {p.currency !== doc.currency && <span className="text-orange-600">• Kur Farklı İşlem</span>}
                                  </div>
                              </div>
                          </div>
                          <div className="flex items-center gap-4">
                              <div className="text-right">
                                  <div className="font-bold text-emerald-600">{p.amount.toLocaleString()} {p.currency}</div>
                                  {p.currency !== doc.currency && (
                                      <div className="text-xs text-slate-400">
                                          ~{(p.amount / (p.processingRate || 1)).toLocaleString(undefined, {maximumFractionDigits: 2})} {doc.currency} (Efektif)
                                      </div>
                                  )}
                              </div>
                              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                  <button onClick={(e) => { e.stopPropagation(); openPaymentModal(p.id); }} className="p-1.5 text-slate-400 hover:text-blue-600 rounded bg-slate-50 hover:bg-blue-50">
                                      <Pencil size={14} />
                                  </button>
                                  <button onClick={(e) => { e.stopPropagation(); handleDeletePayment(p.id); }} className="p-1.5 text-slate-400 hover:text-red-600 rounded bg-slate-50 hover:bg-red-50">
                                      <Trash2 size={14} />
                                  </button>
                              </div>
                          </div>
                      </div>
                  ))}
              </div>
          </div>
      )}

      {/* Invoice Creation Wizard Modal */}
      {isInvoiceModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
              <div className="bg-white rounded-xl shadow-xl w-full max-w-3xl overflow-hidden animate-in fade-in zoom-in duration-200">
                  <div className="p-4 border-b border-slate-200 bg-slate-50 flex justify-between items-center">
                      <h3 className="font-bold text-slate-800 flex items-center gap-2">
                          <FileCode className="text-blue-600" size={20} />
                          Fatura Oluşturma Sihirbazı
                      </h3>
                      <button onClick={() => setIsInvoiceModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                          <X size={24} />
                      </button>
                  </div>
                  
                  <div className="p-6">
                      <p className="text-sm text-slate-500 mb-4 bg-blue-50 p-3 rounded-lg border border-blue-100">
                          Lütfen bu faturada <strong>sevk edilecek / faturalandırılacak</strong> miktarları giriniz.
                          Otomatik olarak kalan miktarlar hesaplanacaktır.
                      </p>
                      
                      <table className="w-full text-left text-sm mb-4">
                          <thead className="bg-slate-100 text-slate-600 uppercase text-xs">
                              <tr>
                                  <th className="px-4 py-2">Ürün</th>
                                  <th className="px-4 py-2 text-center">Sipariş</th>
                                  <th className="px-4 py-2 text-center">Daha Önce Sevk</th>
                                  <th className="px-4 py-2 text-center">Kalan</th>
                                  <th className="px-4 py-2 text-center w-32">Faturaya Ekle</th>
                              </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                              {doc.items.map((item, idx) => {
                                  const alreadyShipped = item.shippedQuantity || 0;
                                  const remaining = item.quantity - alreadyShipped;
                                  if (remaining <= 0) return null; // Don't show fully shipped items

                                  return (
                                      <tr key={idx} className="hover:bg-slate-50">
                                          <td className="px-4 py-3">
                                              <div className="font-medium text-slate-900">{item.productName}</div>
                                              <div className="text-xs text-slate-500">{item.sku}</div>
                                          </td>
                                          <td className="px-4 py-3 text-center">{item.quantity}</td>
                                          <td className="px-4 py-3 text-center text-slate-500">{alreadyShipped}</td>
                                          <td className="px-4 py-3 text-center font-bold text-orange-600">{remaining}</td>
                                          <td className="px-4 py-3">
                                              <input 
                                                  type="number" 
                                                  min="0"
                                                  max={remaining}
                                                  className="w-full border border-slate-300 rounded p-1.5 text-center font-bold text-blue-600 bg-white focus:ring-2 focus:ring-blue-500 outline-none"
                                                  value={invoiceQuantities[idx] || 0}
                                                  onChange={(e) => {
                                                      const val = Math.min(Math.max(0, parseInt(e.target.value) || 0), remaining);
                                                      setInvoiceQuantities(prev => ({...prev, [idx]: val}));
                                                  }}
                                              />
                                          </td>
                                      </tr>
                                  );
                              })}
                          </tbody>
                      </table>
                  </div>

                  <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-end gap-3">
                      <button onClick={() => setIsInvoiceModalOpen(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-200 rounded-lg">Vazgeç</button>
                      <button onClick={executeInvoiceConversion} className="flex items-center gap-2 bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 shadow-sm">
                          <CheckCircle size={18} />
                          Faturayı Oluştur
                      </button>
                  </div>
              </div>
          </div>
      )}

      {isPaymentModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
              <div className="bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden">
                  <div className="p-4 border-b border-slate-200 bg-slate-50 flex justify-between items-center">
                      <h3 className="font-bold text-slate-800">{editingPaymentId ? 'Tahsilatı Düzenle' : 'Tahsilat Ekle / Bakiye Kapat'}</h3>
                      <button onClick={() => setIsPaymentModalOpen(false)} className="text-slate-400 hover:text-slate-600"><X size={20} /></button>
                  </div>
                  <div className="p-6 space-y-4">
                      
                      <div>
                          <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Kasa / Banka Hesabı</label>
                          <select className="w-full border rounded p-2 bg-white text-slate-900" value={selectedAccountId} onChange={(e) => setSelectedAccountId(e.target.value)}>
                                {availableAccounts.length === 0 && <option value="">Bu dövizde hesap yok</option>}
                                {availableAccounts.map(acc => (
                                    <option key={acc.id} value={acc.id}>{acc.name} ({acc.balance.toLocaleString()} {acc.currency})</option>
                                ))}
                          </select>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                          <div>
                             <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Ödeme Dövizi</label>
                             <select className="w-full border rounded p-2 bg-white text-slate-900" value={payCurrency} onChange={(e) => setPayCurrency(e.target.value as Currency)}>
                                 <option value="TRY">TRY (₺)</option>
                                 <option value="USD">USD ($)</option>
                                 <option value="EUR">EUR (€)</option>
                             </select>
                          </div>
                          <div>
                             <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Kur</label>
                             <input type="number" step="0.0001" className="w-full border rounded p-2 bg-slate-50 text-slate-900" value={payExchangeRate} onChange={e => setPayExchangeRate(parseFloat(e.target.value))} readOnly={payCurrency === 'TRY'} />
                          </div>
                      </div>
                      
                      {payCurrency !== doc.currency && (
                          <div className="bg-orange-50 p-3 rounded-lg border border-orange-200">
                              <p className="text-xs font-bold text-orange-800 mb-2 flex items-center gap-1"><Share2 size={12}/> Kur Dönüşümü Gerekli</p>
                              <div className="text-xs text-orange-700 mb-2">Fatura ({doc.currency}) ile Ödeme ({payCurrency}) farklı.</div>
                              
                              <div className="space-y-2">
                                  <label className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                                      <input type="radio" name="rateType" checked={useCurrentRate} onChange={() => setUseCurrentRate(true)} />
                                      <span>Manuel / Güncel Kur Kullan</span>
                                  </label>
                                  {useCurrentRate && (
                                      <div className="pl-6">
                                          <label className="block text-[10px] text-slate-500 uppercase">İşlem Kuru (1 {doc.currency} = ? {payCurrency})</label>
                                          <input type="number" step="0.0001" className="w-full border rounded p-1 text-sm bg-white text-slate-900" value={processingRate} onChange={e => setProcessingRate(parseFloat(e.target.value))} />
                                      </div>
                                  )}
                                  
                                  <label className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                                      <input type="radio" name="rateType" checked={!useCurrentRate} onChange={() => setUseCurrentRate(false)} />
                                      <span>Fatura Tarihindeki Kuru Kullan ({doc.exchangeRate})</span>
                                  </label>
                              </div>
                          </div>
                      )}

                      <div>
                          <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Açıklama</label>
                          <input type="text" className="w-full border rounded p-2 bg-white text-slate-900" value={payDesc} onChange={e => setPayDesc(e.target.value)} />
                      </div>

                      <div>
                          <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Tutar</label>
                          <input type="number" className="w-full border rounded p-2 text-lg font-bold bg-white text-slate-900" placeholder="0.00" value={payAmount} onChange={e => setPayAmount(e.target.value)} />
                          <p className="text-xs text-slate-400 mt-1">Seçili döviz cinsinden giriniz.</p>
                      </div>
                  </div>
                  <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-end gap-3">
                      <button onClick={() => setIsPaymentModalOpen(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-200 rounded-lg">İptal</button>
                      <button onClick={handleSavePayment} className="bg-emerald-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-emerald-700 shadow-sm">
                          {editingPaymentId ? 'Güncelle' : 'Kaydet'}
                      </button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default OrderDetail;