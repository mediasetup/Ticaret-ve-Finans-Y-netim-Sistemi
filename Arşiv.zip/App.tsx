
import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import StockManagement from './pages/StockManagement';
import SalesWorkflow from './pages/SalesWorkflow';
import Reports from './pages/Reports';
import QuoteEditor from './pages/QuoteEditor';
import OrderEditor from './pages/OrderEditor';
import QuoteDetail from './pages/QuoteDetail';
import OrderDetail from './pages/OrderDetail';
import CustomerList from './pages/CustomerList';
import CustomerDetail from './pages/CustomerDetail';
import ReconciliationPage from './pages/Reconciliation';
import BankAccounts from './pages/BankAccounts';
import EInvoiceSettings from './pages/EInvoiceSettings';
import UsersPage from './pages/Users';
import CompanySettings from './pages/CompanySettings';
import { SalesProvider } from './context/SalesContext';

function App() {
  return (
    <SalesProvider>
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/stock" element={<StockManagement />} />
            
            {/* Redirect /sales to /sales/quotes by default */}
            <Route path="/sales" element={<Navigate to="/sales/quotes" replace />} />

            {/* List Views (Shared Component but different URL) */}
            <Route path="/sales/quotes" element={<SalesWorkflow />} />
            <Route path="/sales/orders" element={<SalesWorkflow />} />
            <Route path="/sales/invoices" element={<SalesWorkflow />} />
            
            {/* Customer Modules */}
            <Route path="/sales/customers" element={<CustomerList />} />
            <Route path="/sales/customers/:id" element={<CustomerDetail />} />
            
            {/* Accounting Modules */}
            <Route path="/accounting/banks" element={<BankAccounts />} />
            <Route path="/sales/reconciliation" element={<ReconciliationPage />} />
            
            {/* System / Settings Modules */}
            <Route path="/settings/company" element={<CompanySettings />} />
            <Route path="/settings/users" element={<UsersPage />} />
            <Route path="/einvoice/settings" element={<EInvoiceSettings />} />

            {/* Quote Routes */}
            <Route path="/sales/quote/new" element={<QuoteEditor />} />
            <Route path="/sales/quote/:id" element={<QuoteEditor />} />
            <Route path="/sales/quote/view/:id" element={<QuoteDetail />} />
            
            {/* Order Routes - NOW USING DEDICATED ORDER EDITOR */}
            <Route path="/sales/order/new" element={<OrderEditor />} />
            <Route path="/sales/order/edit/:id" element={<OrderEditor />} />
            <Route path="/sales/order/:id" element={<OrderDetail />} />
            
            {/* Invoice Routes */}
            <Route path="/sales/invoice/:id" element={<OrderDetail />} /> 
            
            <Route path="/reports" element={<Reports />} />
            
            {/* Catch all */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Layout>
      </Router>
    </SalesProvider>
  );
}

export default App;
